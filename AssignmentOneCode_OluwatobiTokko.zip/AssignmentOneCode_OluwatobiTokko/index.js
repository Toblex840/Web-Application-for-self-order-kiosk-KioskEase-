let orderPlacing = [];

document.getElementById("bananabunch-add").onclick = () => SupplyToOrder('Banana Bunch', 4.75);
document.getElementById("orange-add").onclick = () => SupplyToOrder('Orange Single', 0.99);
document.getElementById("avocado-add").onclick = () => SupplyToOrder('Avocado Single', 1.20);
document.getElementById("corn-add").onclick = () => SupplyToOrder('Corn Bunch', 5.00);
document.getElementById("greengrapes-add").onclick = () => SupplyToOrder('Green Grapes', 10.10);

function SupplyToOrder(orderName, price) {
    let quantity = prompt(`Input quantity for ${orderName}:`);
    
    quantity = Number(quantity);
    if (isNaN(quantity) || quantity <= 0) {
        alert('Please input a real number. 😑');
        return;
    }

    orderPlacing.push({ orderName, price, quantity });
    alert(`${orderName} is Successfully added in Checkout. 😘`);
}

document.getElementById("place-order").onclick = commenceToCheckout;

function commenceToCheckout() {
    if (orderPlacing.length === 0) {
        alert("Your order is empty! 😔");
        return;
    }

    let usersName = prompt("Please input a name for the receipt:");

    if (!usersName) {
        alert("Name is important for checkout.");
        return;
    }

    showReceipt(usersName);
}

function showReceipt(usersName) {
    let receiptContains = `<h3>Summary for ${usersName}</h3>`;
    let amount = 0;

    orderPlacing.forEach(item => {
        let itemTotal = item.price * item.quantity;
        receiptContains += `<p>${item.orderName} - $${item.price.toFixed(2)} x ${item.quantity} = $${itemTotal.toFixed(2)}</p>`;
        amount += itemTotal;
    });

    let tax = amount * 0.13;
    let total = amount + tax;

    receiptContains += `<p><strong>Amount:</strong> $${amount.toFixed(2)}</p>`;
    receiptContains += `<p><strong>13% Tax:</strong> $${tax.toFixed(2)}</p>`;
    receiptContains += `<p><strong>Total: $${total.toFixed(2)} </strong></p>`;

    document.getElementById('receiptContains').innerHTML = receiptContains;
    document.getElementById('showcase-receipt').style.display = 'block';
    orderPlacing = [];
}

document.getElementById("end-order").onclick = closeReceipt;

function closeReceipt() {
    document.getElementById('showcase-receipt').style.display = 'none';
}
